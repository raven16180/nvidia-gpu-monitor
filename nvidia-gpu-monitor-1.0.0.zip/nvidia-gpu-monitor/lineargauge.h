#pragma once

#include <QWidget>
#include <QString>

class LinearGauge : public QWidget
{
    Q_OBJECT

public:
    enum ColorScheme {
        BlueToRed,    // For power (cold to hot)
        GreenToRed    // For memory (free to full)
    };

    explicit LinearGauge(QWidget *parent = nullptr);

    void setValue(double value);
    void setRange(double min, double max);
    void setUnit(const QString &unit) { m_unit = unit; update(); }
    void setLabel(const QString &label) { m_label = label; update(); }
    void setColorScheme(ColorScheme scheme) { m_colorScheme = scheme; update(); }

    QSize sizeHint() const override { return QSize(300, 50); }
    QSize minimumSizeHint() const override { return QSize(200, 40); }

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QColor valueColor() const;

    double m_value = 0;
    double m_min = 0;
    double m_max = 100;
    QString m_unit;
    QString m_label;
    ColorScheme m_colorScheme = BlueToRed;
};
