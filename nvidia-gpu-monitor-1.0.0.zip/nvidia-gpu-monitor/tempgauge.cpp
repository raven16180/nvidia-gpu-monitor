#include "tempgauge.h"
#include <QPainter>
#include <QPainterPath>
#include <QConicalGradient>
#include <QtMath>

TempGauge::TempGauge(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(100, 100);
}

void TempGauge::setTemperature(int temp)
{
    if (m_temperature != temp) {
        m_temperature = temp;
        update();
    }
}

QColor TempGauge::temperatureColor() const
{
    // Map temperature to color: green (cool) -> yellow (warm) -> red (hot)
    float ratio = qBound(0.0f, (float)(m_temperature - m_minTemp) / (m_maxTemp - m_minTemp), 1.0f);

    if (ratio < 0.5f) {
        // Green to Yellow (0.0 - 0.5)
        float t = ratio * 2.0f;
        return QColor::fromRgbF(t, 1.0f, 0.0f);
    } else {
        // Yellow to Red (0.5 - 1.0)
        float t = (ratio - 0.5f) * 2.0f;
        return QColor::fromRgbF(1.0f, 1.0f - t, 0.0f);
    }
}

void TempGauge::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);

    int side = qMin(width(), height());
    int margin = 10;
    int arcWidth = 12;

    QRectF outerRect(margin, margin, side - 2 * margin, side - 2 * margin);
    QRectF innerRect = outerRect.adjusted(arcWidth, arcWidth, -arcWidth, -arcWidth);

    // Calculate the angle for current temperature
    // Gauge goes from 225 degrees (bottom-left) to -45 degrees (bottom-right)
    // That's 270 degrees of arc
    float ratio = qBound(0.0f, (float)(m_temperature - m_minTemp) / (m_maxTemp - m_minTemp), 1.0f);
    int spanAngle = (int)(ratio * 270 * 16);  // Qt uses 1/16th of a degree

    // Draw background arc (dark gray)
    QPen bgPen(QColor(60, 60, 60), arcWidth, Qt::SolidLine, Qt::RoundCap);
    painter.setPen(bgPen);
    painter.drawArc(outerRect.adjusted(arcWidth/2, arcWidth/2, -arcWidth/2, -arcWidth/2),
                    225 * 16, -270 * 16);

    // Draw temperature arc with gradient effect
    QColor tempColor = temperatureColor();

    // Create a gradient for glossy effect
    QLinearGradient gradient(outerRect.topLeft(), outerRect.bottomRight());
    gradient.setColorAt(0.0, tempColor.lighter(130));
    gradient.setColorAt(0.5, tempColor);
    gradient.setColorAt(1.0, tempColor.darker(120));

    QPen arcPen(QBrush(gradient), arcWidth, Qt::SolidLine, Qt::RoundCap);
    painter.setPen(arcPen);
    painter.drawArc(outerRect.adjusted(arcWidth/2, arcWidth/2, -arcWidth/2, -arcWidth/2),
                    225 * 16, -spanAngle);

    // Draw inner circle (dark background)
    painter.setPen(Qt::NoPen);
    QRadialGradient innerGradient(outerRect.center(), innerRect.width() / 2);
    innerGradient.setColorAt(0.0, QColor(45, 45, 45));
    innerGradient.setColorAt(0.7, QColor(30, 30, 30));
    innerGradient.setColorAt(1.0, QColor(20, 20, 20));
    painter.setBrush(innerGradient);
    painter.drawEllipse(innerRect);

    // Draw temperature text (just the number)
    painter.setPen(tempColor);
    QFont tempFont("Sans", side / 5, QFont::Bold);
    painter.setFont(tempFont);
    painter.drawText(innerRect, Qt::AlignCenter, QString::number(m_temperature));

    // Draw min label (bottom-left)
    painter.setPen(QColor(100, 100, 100));
    QFont minMaxFont("Sans", 8);
    painter.setFont(minMaxFont);
    painter.drawText(QPointF(margin + 5, side - margin + 2), QString::number(m_minTemp));

    // Draw "C" label (bottom-center, between gauge ends)
    painter.setPen(QColor(150, 150, 150));
    QFont labelFont("Sans", 9, QFont::Bold);
    painter.setFont(labelFont);
    painter.drawText(QRectF(0, side - margin - 5, side, 20), Qt::AlignHCenter | Qt::AlignTop, "°C");

    // Draw max label (bottom-right)
    painter.setPen(QColor(100, 100, 100));
    painter.setFont(minMaxFont);
    painter.drawText(QPointF(side - margin - 20, side - margin + 2), QString::number(m_maxTemp));
}
