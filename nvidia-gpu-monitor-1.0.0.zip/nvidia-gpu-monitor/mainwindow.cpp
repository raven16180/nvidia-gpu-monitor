#include "mainwindow.h"
#include "tempgauge.h"
#include "fangauge.h"
#include "lineargauge.h"
#include <QFont>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QPixmap>
#include <QCoreApplication>
#include <QFileInfo>
#include <QCloseEvent>
#include <QPainter>
#include <QApplication>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle("NVIDIA GPU Monitor");
    resize(650, 480);

    // Set glossy black background
    setStyleSheet(
        "QMainWindow { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, "
        "  stop:0 #2a2a2a, stop:0.5 #1a1a1a, stop:1 #252525); }"
    );

    setupUi();
    setupTrayIcon();

    process = new QProcess(this);
    connect(process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &MainWindow::onProcessFinished);

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::updateNvidiaSmi);
    timer->start(10000);

    updateNvidiaSmi();
}

void MainWindow::setupUi()
{
    QWidget *centralWidget = new QWidget(this);
    centralWidget->setStyleSheet("background: transparent;");
    setCentralWidget(centralWidget);

    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setContentsMargins(20, 15, 20, 15);
    mainLayout->setSpacing(15);

    // === HEADER SECTION ===
    QHBoxLayout *headerLayout = new QHBoxLayout();
    headerLayout->setSpacing(15);

    // GPU Image - look in same directory as executable
    gpuImageLabel = new QLabel(this);
    QString imagePath = QCoreApplication::applicationDirPath() + "/graphics_card.png";
    QPixmap gpuPixmap(imagePath);
    if (!gpuPixmap.isNull()) {
        gpuPixmap = gpuPixmap.scaled(180, 130, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        gpuImageLabel->setPixmap(gpuPixmap);
    }
    gpuImageLabel->setFixedSize(190, 140);
    gpuImageLabel->setAlignment(Qt::AlignCenter);
    headerLayout->addWidget(gpuImageLabel);

    // Title and GPU name
    QVBoxLayout *titleLayout = new QVBoxLayout();
    titleLayout->setSpacing(3);

    QLabel *titleLabel = new QLabel("NVIDIA GPU Monitor", this);
    QFont titleFont("Sans", 18, QFont::Bold);
    titleLabel->setFont(titleFont);
    titleLabel->setStyleSheet("color: #76B900;");
    titleLayout->addWidget(titleLabel);

    gpuNameLabel = new QLabel("--", this);
    QFont gpuFont("Sans", 12, QFont::Bold);
    gpuNameLabel->setFont(gpuFont);
    gpuNameLabel->setStyleSheet("color: #FFFFFF;");
    gpuNameLabel->setWordWrap(true);
    titleLayout->addWidget(gpuNameLabel);

    gpuIndexLabel = new QLabel("GPU 0", this);
    QFont indexFont("Sans", 10);
    gpuIndexLabel->setFont(indexFont);
    gpuIndexLabel->setStyleSheet("color: #76B900;");
    titleLayout->addWidget(gpuIndexLabel);

    titleLayout->addStretch();
    headerLayout->addLayout(titleLayout);
    headerLayout->addStretch();

    // Temperature gauge
    tempGauge = new TempGauge(this);
    tempGauge->setMinTemp(30);
    tempGauge->setMaxTemp(100);
    tempGauge->setFixedSize(120, 120);
    headerLayout->addWidget(tempGauge);

    // Fan gauge
    fanGauge = new FanGauge(this);
    fanGauge->setFixedSize(120, 120);
    headerLayout->addWidget(fanGauge);

    mainLayout->addLayout(headerLayout);

    // === LINEAR GAUGES SECTION ===
    QVBoxLayout *gaugesLayout = new QVBoxLayout();
    gaugesLayout->setSpacing(8);

    // Power gauge
    powerGauge = new LinearGauge(this);
    powerGauge->setLabel("Power");
    powerGauge->setUnit("W");
    powerGauge->setRange(0, 575);
    powerGauge->setColorScheme(LinearGauge::BlueToRed);
    powerGauge->setFixedHeight(45);
    gaugesLayout->addWidget(powerGauge);

    // Memory gauge
    memoryGauge = new LinearGauge(this);
    memoryGauge->setLabel("Memory");
    memoryGauge->setUnit("MiB");
    memoryGauge->setRange(0, 32607);
    memoryGauge->setColorScheme(LinearGauge::GreenToRed);
    memoryGauge->setFixedHeight(45);
    gaugesLayout->addWidget(memoryGauge);

    mainLayout->addLayout(gaugesLayout);

    // === INFO GRID (2x2) ===
    QGridLayout *infoGrid = new QGridLayout();
    infoGrid->setSpacing(15);
    infoGrid->setContentsMargins(10, 10, 10, 10);

    auto createInfoItem = [this](const QString &label) -> QLabel* {
        QWidget *container = new QWidget(this);
        QVBoxLayout *layout = new QVBoxLayout(container);
        layout->setContentsMargins(0, 0, 0, 0);
        layout->setSpacing(2);

        QLabel *nameLabel = new QLabel(label, container);
        nameLabel->setStyleSheet("color: #888; font-size: 11px;");
        layout->addWidget(nameLabel);

        QLabel *valueLabel = new QLabel("--", container);
        QFont valueFont("Sans", 14, QFont::Bold);
        valueLabel->setFont(valueFont);
        valueLabel->setStyleSheet("color: #FFF;");
        layout->addWidget(valueLabel);

        return valueLabel;
    };

    utilizationLabel = createInfoItem("GPU Utilization");
    infoGrid->addWidget(utilizationLabel->parentWidget(), 0, 0);

    perfStateLabel = createInfoItem("Performance State");
    infoGrid->addWidget(perfStateLabel->parentWidget(), 0, 1);

    busIdLabel = createInfoItem("Bus ID");
    infoGrid->addWidget(busIdLabel->parentWidget(), 1, 0);

    computeModeLabel = createInfoItem("Compute Mode");
    infoGrid->addWidget(computeModeLabel->parentWidget(), 1, 1);

    mainLayout->addLayout(infoGrid);

    // === FOOTER ===
    QHBoxLayout *footerLayout = new QHBoxLayout();

    // Separator line
    QFrame *separator = new QFrame(this);
    separator->setFrameShape(QFrame::HLine);
    separator->setStyleSheet("background-color: #444;");
    separator->setFixedHeight(1);

    driverLabel = new QLabel("Driver: --", this);
    driverLabel->setStyleSheet("color: #666; font-size: 10px;");

    cudaLabel = new QLabel("CUDA: --", this);
    cudaLabel->setStyleSheet("color: #666; font-size: 10px;");

    footerLayout->addWidget(driverLabel);
    footerLayout->addStretch();
    footerLayout->addWidget(cudaLabel);

    mainLayout->addWidget(separator);
    mainLayout->addLayout(footerLayout);
}

void MainWindow::updateNvidiaSmi()
{
    if (process->state() != QProcess::NotRunning)
        return;

    QStringList args;
    args << "--query-gpu=index,name,fan.speed,temperature.gpu,power.draw,power.limit,"
            "pci.bus_id,memory.used,memory.total,utilization.gpu,compute_mode,pstate,"
            "driver_version"
         << "--format=csv,noheader,nounits";

    process->start("nvidia-smi", args);
}

void MainWindow::onProcessFinished(int exitCode, QProcess::ExitStatus status)
{
    Q_UNUSED(exitCode);
    Q_UNUSED(status);

    QString output = process->readAllStandardOutput().trimmed();
    parseAndDisplay(output);
}

void MainWindow::parseAndDisplay(const QString &output)
{
    // CSV: index, name, fan.speed, temperature.gpu, power.draw, power.limit,
    //      pci.bus_id, memory.used, memory.total, utilization.gpu,
    //      compute_mode, pstate, driver_version
    QStringList fields = output.split(',');

    if (fields.size() < 13) {
        gpuNameLabel->setText("Error reading nvidia-smi");
        return;
    }

    for (auto &field : fields) {
        field = field.trimmed();
    }

    QString gpuIndex = fields[0];
    QString name = fields[1];
    QString fan = fields[2];
    QString temp = fields[3];
    QString powerDraw = fields[4];
    QString powerLimit = fields[5];
    QString busId = fields[6];
    QString memUsed = fields[7];
    QString memTotal = fields[8];
    QString utilization = fields[9];
    QString computeMode = fields[10];
    QString perfState = fields[11];
    QString driverVersion = fields[12];

    // Update header
    gpuNameLabel->setText(name);
    gpuIndexLabel->setText(QString("GPU %1").arg(gpuIndex));

    // Update radial gauges
    tempGauge->setTemperature(temp.toInt());
    fanGauge->setFanSpeed(fan.toInt());

    // Update linear gauges
    double powerVal = powerDraw.toDouble();
    double powerMax = powerLimit.toDouble();
    powerGauge->setRange(0, powerMax);
    powerGauge->setValue(powerVal);

    double memUsedVal = memUsed.toDouble();
    double memTotalVal = memTotal.toDouble();
    memoryGauge->setRange(0, memTotalVal);
    memoryGauge->setValue(memUsedVal);

    // Update 2x2 info grid
    int utilVal = utilization.toInt();
    QString utilColor = "#00FF00";
    if (utilVal > 50) utilColor = "#FFFF00";
    if (utilVal > 90) utilColor = "#FF8800";
    utilizationLabel->setText(QString("%1%").arg(utilization));
    utilizationLabel->setStyleSheet(QString("color: %1; font-size: 14px; font-weight: bold;").arg(utilColor));

    perfStateLabel->setText(perfState);
    busIdLabel->setText(busId);
    computeModeLabel->setText(computeMode);

    // Update footer
    driverLabel->setText("Driver: " + driverVersion);
    cudaLabel->setText("CUDA: 12.8");

    // Update tray icon
    lastTemp = temp.toInt();
    lastUtil = utilization.toInt();
    updateTrayIcon(lastTemp, lastUtil);
}

void MainWindow::setupTrayIcon()
{
    trayIcon = new QSystemTrayIcon(this);
    trayIcon->setIcon(createTempIcon(0));
    trayIcon->setToolTip("NVIDIA GPU Monitor\nLoading...");

    // Create context menu
    trayMenu = new QMenu(this);

    QAction *showAction = trayMenu->addAction("Show Monitor");
    connect(showAction, &QAction::triggered, this, &MainWindow::showWindow);

    trayMenu->addSeparator();

    QAction *quitAction = trayMenu->addAction("Quit");
    connect(quitAction, &QAction::triggered, this, &MainWindow::quitApp);

    trayIcon->setContextMenu(trayMenu);

    connect(trayIcon, &QSystemTrayIcon::activated,
            this, &MainWindow::onTrayIconActivated);

    trayIcon->show();
}

QIcon MainWindow::createTempIcon(int temp)
{
    QPixmap pixmap(64, 64);
    pixmap.fill(Qt::transparent);

    QPainter painter(&pixmap);
    painter.setRenderHint(QPainter::Antialiasing, true);

    // Determine color based on temperature
    QColor color;
    if (temp < 50) {
        color = QColor(0, 255, 0);       // Green
    } else if (temp < 70) {
        color = QColor(255, 255, 0);     // Yellow
    } else if (temp < 85) {
        color = QColor(255, 165, 0);     // Orange
    } else {
        color = QColor(255, 0, 0);       // Red
    }

    // Draw filled circle background
    painter.setPen(Qt::NoPen);
    painter.setBrush(QColor(30, 30, 30));
    painter.drawEllipse(2, 2, 60, 60);

    // Draw colored arc based on temp (0-100 mapped to 0-270 degrees)
    int arcSpan = qBound(0, temp, 100) * 270 / 100;
    QPen arcPen(color, 6, Qt::SolidLine, Qt::RoundCap);
    painter.setPen(arcPen);
    painter.drawArc(6, 6, 52, 52, 225 * 16, -arcSpan * 16);

    // Draw temperature text
    painter.setPen(Qt::white);
    QFont font("Sans", 16, QFont::Bold);
    painter.setFont(font);
    painter.drawText(pixmap.rect(), Qt::AlignCenter, QString::number(temp));

    return QIcon(pixmap);
}

void MainWindow::updateTrayIcon(int temp, int utilization)
{
    trayIcon->setIcon(createTempIcon(temp));

    QString tooltip = QString("NVIDIA GPU Monitor\n"
                              "Temperature: %1°C\n"
                              "Utilization: %2%\n"
                              "Click to show/hide")
                      .arg(temp).arg(utilization);
    trayIcon->setToolTip(tooltip);
}

void MainWindow::onTrayIconActivated(QSystemTrayIcon::ActivationReason reason)
{
    if (reason == QSystemTrayIcon::Trigger ||
        reason == QSystemTrayIcon::DoubleClick) {
        if (isVisible()) {
            hide();
        } else {
            showWindow();
        }
    }
}

void MainWindow::showWindow()
{
    show();
    raise();
    activateWindow();
}

void MainWindow::quitApp()
{
    trayIcon->hide();
    QApplication::quit();
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    if (trayIcon->isVisible()) {
        hide();
        event->ignore();
    } else {
        event->accept();
    }
}
