#include "fangauge.h"
#include <QPainter>
#include <QtMath>

FanGauge::FanGauge(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(100, 100);
}

void FanGauge::setFanSpeed(int speed)
{
    if (m_fanSpeed != speed) {
        m_fanSpeed = qBound(0, speed, 100);
        update();
    }
}

QColor FanGauge::speedColor() const
{
    // Cyan (low) -> Blue (medium) -> Purple (high)
    float ratio = m_fanSpeed / 100.0f;

    if (ratio < 0.5f) {
        // Cyan to Blue
        float t = ratio * 2.0f;
        return QColor::fromRgbF(0.0f, 1.0f - t * 0.5f, 1.0f);
    } else {
        // Blue to Purple/Magenta
        float t = (ratio - 0.5f) * 2.0f;
        return QColor::fromRgbF(t * 0.8f, 0.5f - t * 0.3f, 1.0f);
    }
}

void FanGauge::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);

    int side = qMin(width(), height());
    int margin = 10;
    int arcWidth = 12;

    QRectF outerRect(margin, margin, side - 2 * margin, side - 2 * margin);
    QRectF innerRect = outerRect.adjusted(arcWidth, arcWidth, -arcWidth, -arcWidth);

    // Calculate angle for current fan speed (0-100%)
    float ratio = m_fanSpeed / 100.0f;
    int spanAngle = (int)(ratio * 270 * 16);

    // Draw background arc
    QPen bgPen(QColor(60, 60, 60), arcWidth, Qt::SolidLine, Qt::RoundCap);
    painter.setPen(bgPen);
    painter.drawArc(outerRect.adjusted(arcWidth/2, arcWidth/2, -arcWidth/2, -arcWidth/2),
                    225 * 16, -270 * 16);

    // Draw fan speed arc with gradient
    QColor fanColor = speedColor();
    QLinearGradient gradient(outerRect.topLeft(), outerRect.bottomRight());
    gradient.setColorAt(0.0, fanColor.lighter(130));
    gradient.setColorAt(0.5, fanColor);
    gradient.setColorAt(1.0, fanColor.darker(120));

    QPen arcPen(QBrush(gradient), arcWidth, Qt::SolidLine, Qt::RoundCap);
    painter.setPen(arcPen);
    painter.drawArc(outerRect.adjusted(arcWidth/2, arcWidth/2, -arcWidth/2, -arcWidth/2),
                    225 * 16, -spanAngle);

    // Draw inner circle
    painter.setPen(Qt::NoPen);
    QRadialGradient innerGradient(outerRect.center(), innerRect.width() / 2);
    innerGradient.setColorAt(0.0, QColor(45, 45, 45));
    innerGradient.setColorAt(0.7, QColor(30, 30, 30));
    innerGradient.setColorAt(1.0, QColor(20, 20, 20));
    painter.setBrush(innerGradient);
    painter.drawEllipse(innerRect);

    // Draw fan speed text (just the number)
    painter.setPen(fanColor);
    QFont speedFont("Sans", side / 5, QFont::Bold);
    painter.setFont(speedFont);
    painter.drawText(innerRect, Qt::AlignCenter, QString::number(m_fanSpeed));

    // Draw min label (bottom-left)
    painter.setPen(QColor(100, 100, 100));
    QFont minMaxFont("Sans", 8);
    painter.setFont(minMaxFont);
    painter.drawText(QPointF(margin + 5, side - margin + 2), "0");

    // Draw "FAN" label (bottom-center, between gauge ends)
    painter.setPen(QColor(150, 150, 150));
    QFont labelFont("Sans", 9, QFont::Bold);
    painter.setFont(labelFont);
    painter.drawText(QRectF(0, side - margin - 5, side, 20), Qt::AlignHCenter | Qt::AlignTop, "FAN %");

    // Draw max label (bottom-right)
    painter.setPen(QColor(100, 100, 100));
    painter.setFont(minMaxFont);
    painter.drawText(QPointF(side - margin - 25, side - margin + 2), "100");
}
