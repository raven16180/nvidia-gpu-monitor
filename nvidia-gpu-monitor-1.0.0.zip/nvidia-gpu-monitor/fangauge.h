#pragma once

#include <QWidget>

class FanGauge : public QWidget
{
    Q_OBJECT

public:
    explicit FanGauge(QWidget *parent = nullptr);

    void setFanSpeed(int speed);
    int fanSpeed() const { return m_fanSpeed; }

    QSize sizeHint() const override { return QSize(120, 120); }
    QSize minimumSizeHint() const override { return QSize(80, 80); }

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QColor speedColor() const;
    int m_fanSpeed = 0;
};
