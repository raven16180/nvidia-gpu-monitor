#pragma once

#include <QWidget>

class TempGauge : public QWidget
{
    Q_OBJECT

public:
    explicit TempGauge(QWidget *parent = nullptr);

    void setTemperature(int temp);
    int temperature() const { return m_temperature; }

    void setMinTemp(int min) { m_minTemp = min; update(); }
    void setMaxTemp(int max) { m_maxTemp = max; update(); }

    QSize sizeHint() const override { return QSize(120, 120); }
    QSize minimumSizeHint() const override { return QSize(80, 80); }

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QColor temperatureColor() const;

    int m_temperature = 0;
    int m_minTemp = 30;
    int m_maxTemp = 100;
};
