#!/bin/bash

# NVIDIA GPU Monitor - Installation Script

set -e

INSTALL_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/.local/share/applications"
AUTOSTART_DIR="$HOME/.config/autostart"

echo "NVIDIA GPU Monitor - Installer"
echo "==============================="
echo

# Check if nvidia-smi is available
if ! command -v nvidia-smi &> /dev/null; then
    echo "Warning: nvidia-smi not found. Make sure NVIDIA drivers are installed."
fi

# Check if build exists
if [ ! -f "build/nvidia-monitor" ]; then
    echo "Building application..."
    mkdir -p build
    cd build
    cmake ..
    make -j$(nproc)
    cd ..
fi

# Create directories
echo "Creating directories..."
mkdir -p "$INSTALL_DIR"
mkdir -p "$DESKTOP_DIR"

# Copy files
echo "Installing files..."
cp build/nvidia-monitor "$INSTALL_DIR/"
cp graphics_card.png "$INSTALL_DIR/"
cp nvidia-gpu-monitor.png "$INSTALL_DIR/"

# Create desktop entry
echo "Creating desktop entry..."
cat > "$DESKTOP_DIR/nvidia-gpu-monitor.desktop" << EOF
[Desktop Entry]
Type=Application
Name=NVIDIA GPU Monitor
Comment=Monitor NVIDIA GPU temperature and performance
Exec=$INSTALL_DIR/nvidia-monitor
Icon=$INSTALL_DIR/nvidia-gpu-monitor.png
Terminal=false
Categories=System;Monitor;
Keywords=nvidia;gpu;monitor;temperature;
EOF

# Ask about autostart
echo
read -p "Enable autostart with KDE? [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    mkdir -p "$AUTOSTART_DIR"
    cp "$DESKTOP_DIR/nvidia-gpu-monitor.desktop" "$AUTOSTART_DIR/"
    echo "Autostart enabled."
fi

echo
echo "Installation complete!"
echo
echo "You can now:"
echo "  - Run from terminal: $INSTALL_DIR/nvidia-monitor"
echo "  - Find in application menu: 'NVIDIA GPU Monitor'"
echo
echo "Make sure $INSTALL_DIR is in your PATH."
