#include "lineargauge.h"
#include <QPainter>
#include <QLinearGradient>

LinearGauge::LinearGauge(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(200, 45);
}

void LinearGauge::setValue(double value)
{
    if (m_value != value) {
        m_value = qBound(m_min, value, m_max);
        update();
    }
}

void LinearGauge::setRange(double min, double max)
{
    m_min = min;
    m_max = max;
    m_value = qBound(m_min, m_value, m_max);
    update();
}

QColor LinearGauge::valueColor() const
{
    double ratio = (m_max > m_min) ? (m_value - m_min) / (m_max - m_min) : 0;
    ratio = qBound(0.0, ratio, 1.0);

    if (m_colorScheme == BlueToRed) {
        // Blue (0) -> Cyan -> Green -> Yellow -> Red (1)
        if (ratio < 0.25) {
            float t = ratio * 4.0f;
            return QColor::fromRgbF(0.0f, t, 1.0f);  // Blue to Cyan
        } else if (ratio < 0.5) {
            float t = (ratio - 0.25f) * 4.0f;
            return QColor::fromRgbF(0.0f, 1.0f, 1.0f - t);  // Cyan to Green
        } else if (ratio < 0.75) {
            float t = (ratio - 0.5f) * 4.0f;
            return QColor::fromRgbF(t, 1.0f, 0.0f);  // Green to Yellow
        } else {
            float t = (ratio - 0.75f) * 4.0f;
            return QColor::fromRgbF(1.0f, 1.0f - t, 0.0f);  // Yellow to Red
        }
    } else {
        // Green to Yellow to Red
        if (ratio < 0.5f) {
            float t = ratio * 2.0f;
            return QColor::fromRgbF(t, 1.0f, 0.0f);
        } else {
            float t = (ratio - 0.5f) * 2.0f;
            return QColor::fromRgbF(1.0f, 1.0f - t, 0.0f);
        }
    }
}

void LinearGauge::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);

    int barHeight = 16;
    int margin = 5;
    int labelWidth = 80;
    int valueWidth = 100;

    int barX = labelWidth + margin;
    int barY = (height() - barHeight) / 2;
    int barWidth = width() - labelWidth - valueWidth - 3 * margin;

    // Draw label
    painter.setPen(QColor(150, 150, 150));
    QFont labelFont("Sans", 11, QFont::Bold);
    painter.setFont(labelFont);
    painter.drawText(QRect(0, 0, labelWidth, height()), Qt::AlignVCenter | Qt::AlignRight, m_label);

    // Draw background bar with rounded corners
    QRectF bgRect(barX, barY, barWidth, barHeight);
    painter.setPen(Qt::NoPen);

    // Background gradient (glossy effect)
    QLinearGradient bgGradient(bgRect.topLeft(), bgRect.bottomLeft());
    bgGradient.setColorAt(0.0, QColor(50, 50, 50));
    bgGradient.setColorAt(0.5, QColor(35, 35, 35));
    bgGradient.setColorAt(1.0, QColor(45, 45, 45));
    painter.setBrush(bgGradient);
    painter.drawRoundedRect(bgRect, barHeight / 2, barHeight / 2);

    // Draw filled portion
    double ratio = (m_max > m_min) ? (m_value - m_min) / (m_max - m_min) : 0;
    ratio = qBound(0.0, ratio, 1.0);
    int fillWidth = (int)(barWidth * ratio);

    if (fillWidth > 0) {
        QRectF fillRect(barX, barY, fillWidth, barHeight);
        QColor fillColor = valueColor();

        // Glossy gradient for fill
        QLinearGradient fillGradient(fillRect.topLeft(), fillRect.bottomLeft());
        fillGradient.setColorAt(0.0, fillColor.lighter(140));
        fillGradient.setColorAt(0.3, fillColor.lighter(110));
        fillGradient.setColorAt(0.5, fillColor);
        fillGradient.setColorAt(0.7, fillColor.darker(110));
        fillGradient.setColorAt(1.0, fillColor.darker(130));

        painter.setBrush(fillGradient);
        painter.drawRoundedRect(fillRect, barHeight / 2, barHeight / 2);

        // Add highlight line at top
        painter.setPen(QPen(QColor(255, 255, 255, 60), 1));
        painter.drawLine(QPointF(barX + barHeight/2, barY + 2),
                        QPointF(barX + fillWidth - barHeight/2, barY + 2));
    }

    // Draw border
    painter.setPen(QPen(QColor(80, 80, 80), 1));
    painter.setBrush(Qt::NoBrush);
    painter.drawRoundedRect(bgRect, barHeight / 2, barHeight / 2);

    // Draw value text
    QColor valColor = valueColor();
    painter.setPen(valColor);
    QFont valueFont("Sans", 11, QFont::Bold);
    painter.setFont(valueFont);
    QString valueText = QString("%1 / %2 %3").arg((int)m_value).arg((int)m_max).arg(m_unit);
    painter.drawText(QRect(barX + barWidth + margin, 0, valueWidth, height()),
                     Qt::AlignVCenter | Qt::AlignLeft, valueText);
}
