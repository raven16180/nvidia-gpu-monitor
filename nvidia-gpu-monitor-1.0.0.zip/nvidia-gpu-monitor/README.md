# NVIDIA GPU Monitor

A sleek Qt6 desktop widget for monitoring NVIDIA GPU performance on KDE Plasma.

## Features

- **Real-time monitoring** - Updates every 10 seconds
- **Temperature gauge** - Radial gauge with color-coded display (green/yellow/red)
- **Fan speed gauge** - Radial gauge showing fan RPM percentage
- **Power consumption** - Linear gauge (blue to red gradient)
- **Memory usage** - Linear gauge with percentage display
- **System tray integration** - Minimizes to tray, shows temperature in icon
- **Dark glossy theme** - Modern black gradient design
- **KDE autostart support** - Optional automatic startup

## Requirements

- Linux with NVIDIA GPU
- NVIDIA drivers with `nvidia-smi` command available
- Qt6 (Widgets module)
- CMake 3.16+
- C++17 compiler

### Installing Dependencies

**Ubuntu/Debian:**
```bash
sudo apt install cmake qt6-base-dev
```

**Fedora:**
```bash
sudo dnf install cmake qt6-qtbase-devel
```

**Arch Linux:**
```bash
sudo pacman -S cmake qt6-base
```

## Quick Start

### Option 1: Use the Install Script (Recommended)

```bash
# Clone or extract the project
cd nvidia-gpu-monitor

# Run the installer
./install.sh
```

The install script will:
1. Build the application if not already built
2. Copy files to `~/.local/bin/`
3. Create a desktop entry in the application menu
4. Optionally enable autostart with KDE

### Option 2: Manual Build and Run

```bash
cd nvidia-gpu-monitor
mkdir build && cd build
cmake ..
make -j$(nproc)

# Run directly from build directory
./nvidia-monitor
```

**Note:** The `graphics_card.png` image must be in the same directory as the executable.

### Option 3: Run from Any Directory

After building, copy both files to your preferred location:
```bash
mkdir -p ~/apps/nvidia-monitor
cp build/nvidia-monitor ~/apps/nvidia-monitor/
cp graphics_card.png ~/apps/nvidia-monitor/
cd ~/apps/nvidia-monitor
./nvidia-monitor
```

## KDE Autostart (Manual Setup)

If you didn't use the install script, you can enable autostart manually:

```bash
mkdir -p ~/.config/autostart

cat > ~/.config/autostart/nvidia-gpu-monitor.desktop << 'EOF'
[Desktop Entry]
Type=Application
Name=NVIDIA GPU Monitor
Comment=Monitor NVIDIA GPU temperature and performance
Exec=/path/to/nvidia-monitor
Icon=nvidia-settings
Terminal=false
Categories=System;Monitor;
EOF
```

Replace `/path/to/nvidia-monitor` with the actual path to the executable.

## Usage

### Window Controls
- **Close button (X)** - Minimizes to system tray (does not quit)

### System Tray
- **Left-click** - Show/hide the monitor window
- **Right-click** - Opens context menu:
  - Show Monitor - Brings window to front
  - Quit - Exits the application completely

### Tray Icon
The tray icon displays the current GPU temperature with a color-coded arc:
- **Green** - Cool (below 50°C)
- **Yellow** - Warm (50-70°C)
- **Orange** - Hot (70-85°C)
- **Red** - Critical (above 85°C)

Hover over the icon to see a tooltip with temperature and GPU utilization.

## Customization

### GPU Image
Replace `graphics_card.png` with your own GPU image. The image should be:
- PNG format
- Placed in the same directory as the executable
- Recommended size: ~400x300 pixels (will be scaled automatically)

## Uninstallation

If installed with the install script:
```bash
rm ~/.local/bin/nvidia-monitor
rm ~/.local/bin/graphics_card.png
rm ~/.local/share/applications/nvidia-gpu-monitor.desktop
rm ~/.config/autostart/nvidia-gpu-monitor.desktop
```

## Troubleshooting

### "nvidia-smi not found"
Make sure NVIDIA drivers are installed and `nvidia-smi` is in your PATH:
```bash
nvidia-smi
```

### Image not displaying
Ensure `graphics_card.png` is in the same directory as the `nvidia-monitor` executable.

### Application won't start
Check Qt6 is installed:
```bash
qmake6 --version
```

## License

MIT License - Free to use, modify, and distribute.

## Credits

Built with Qt6 for KDE Plasma desktop.
