#pragma once

#include <QMainWindow>
#include <QTimer>
#include <QProcess>
#include <QLabel>
#include <QString>
#include <QSystemTrayIcon>
#include <QMenu>

class TempGauge;
class FanGauge;
class LinearGauge;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void updateNvidiaSmi();
    void onProcessFinished(int exitCode, QProcess::ExitStatus status);
    void onTrayIconActivated(QSystemTrayIcon::ActivationReason reason);
    void showWindow();
    void quitApp();

private:
    void setupUi();
    void setupTrayIcon();
    void parseAndDisplay(const QString &output);
    void updateTrayIcon(int temp, int utilization);
    QIcon createTempIcon(int temp);

    QTimer *timer;
    QProcess *process;

    // Image label
    QLabel *gpuImageLabel;

    // GPU name and info box title
    QLabel *gpuNameLabel;
    QLabel *gpuIndexLabel;

    // Radial gauges
    TempGauge *tempGauge;
    FanGauge *fanGauge;

    // Linear gauges
    LinearGauge *powerGauge;
    LinearGauge *memoryGauge;

    // Text labels for 2x2 grid
    QLabel *utilizationLabel;
    QLabel *perfStateLabel;
    QLabel *busIdLabel;
    QLabel *computeModeLabel;

    // Footer labels
    QLabel *driverLabel;
    QLabel *cudaLabel;

    // System tray
    QSystemTrayIcon *trayIcon;
    QMenu *trayMenu;
    int lastTemp = 0;
    int lastUtil = 0;
};
